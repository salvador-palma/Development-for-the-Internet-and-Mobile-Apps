### TODO List - Semana 2

#### Exercicio 1

1.1 Done
1.2 Done
1.3 Done
1.4 Done
1.5 Done
1.6 Done
1.7 Done

#### Exercicio 2

2.1 Done
2.2 Done
    2.2.1 Done
    2.2.2 Done
    2.2.3 Done (<select>)
2.3 Done

#### Exercicio 3

3.1 Done
3.2 Done
3.3 Done
3.4 Done

